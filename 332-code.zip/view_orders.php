<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="vorder.css">
</head>
<body>
    <h1>View Orders</h1>
    <form method="post" action="">
      <label for="order_date">Order Date(YYYY-MM-DD):</label>
      <input type="date" id="order_date" name="order_date" required>
	  <input type="submit" value="Submit">
	<a href="restaurant.php">back to homepage</a>
    </form>
	<hr>
<?php
if(isset($_POST['order_date'])){
	
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "restaurantDB"; 
	
	$con = new mysqli($servername, $username, $password, $dbname);
	if($con->connect_error){
		die("Connection failed: " . $con->connect_error);
	}
	$query = 'select customer.firstName, customer.lastName, orderfood.item,
								orderfood.price, orderfood.tip, delivery.name from customer
								join CustomerPlaseOrderFromRestaurant on
								customer.email = CustomerPlaseOrderFromRestaurant.CustomerEmail
								join orderfood on
								orderfood.ID = CustomerPlaseOrderFromRestaurant.orderID
								join DeliverySchedule on
								orderfood.id = DeliverySchedule.itemsID
								join delivery on
								DeliverySchedule.deliveryID = delivery.ID
								where orderfood.orderdate = ?
								group by orderfood.ID';
	$stm = $con->prepare($query);
	if ($stm === false) {
			echo "Error: " . $conn->error;
		} else {
			// Bind parameter to the prepared statement
			$stm->bind_param("s", $_POST['order_date']);

			// Execute the prepared statement
			$stm->execute();

			// Store result
			$result = $stm->get_result();

			// Check if any results were returned
			if ($result->num_rows > 0) {
				// Display table headers
				echo "<table><tr><th>Customer Name</th><th>Items</th><th>Total Amount</th><th>Tip</th><th>Delivery Person</th></tr>";

				// Display data for each order
				while($row = $result->fetch_assoc()) {
					echo "<tr><td>" . $row["firstName"] . " " . $row["lastName"] . "</td><td>" . $row["item"] . "</td><td>$" . $row["price"] . "</td><td>$" . $row["tip"] . "</td><td>" . $row["name"] . "</td></tr>";
				}

				// Close table
				echo "</table>";
			} else {
				echo "No orders found on this date.";
			}

			// Free result set
			$result->free_result();

			// Close statement
			$stm->close();
		}

		// Close connection
		$con->close();
	}
	?>
</body>
</html>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
