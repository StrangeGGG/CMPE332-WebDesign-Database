<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="odate.css">
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "restaurantDB";
$con = new mysqli($servername, $username, $password, $dbname);

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

$query = 'select date(orderdate) as orderdate, count(*) as ordercount from orderfood group by date(orderdate)';
$result = $con->query($query);

echo "<table><tr><th>Date</th><th>Number of Orders</th></tr>";

while ($row = $result->fetch_assoc()) {
    echo "<tr><td>" . $row["orderdate"] . "</td><td>" . $row["ordercount"] . "</td></tr>";
}

echo "</table>";

$con->close();
?>
<a href="restaurant.php">Back to Main Page</a>
</body>
</html>