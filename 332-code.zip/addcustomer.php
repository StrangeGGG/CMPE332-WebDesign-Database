<!DOCTYPE html>
<html>
<body>
<head>
<link rel="stylesheet" type="text/css" href="ac.css">
</head>
    <form action="" method="post">
	    <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
		
        <label for="firstName">First Name:</label>
        <input type="text" id="firstName" name="firstName" required>

        <label for="lastName">Last Name:</label>
        <input type="text" id="lastName" name="lastName" required>
		
		<label for="street">Street:</label>
        <input type="street" id="street" name="street" required>
		
		<label for="city">City:</label>
        <input type="city" id="city" name="city" required>
		
		 <label for="pc">PC:</label>
        <input type="pc" id="pc" name="pc" required>
		
        <label for="phone">Phone Number:</label>
        <input type="tel" id="phone" name="phone" required>

        <input type="submit" name="submit" value="Add Customer">
	</form>
	<a href="restaurant.php">Back to Main Page</a>
<?php
if (isset($_POST['submit'])) {
	$email = $_POST['email'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
	$street = $_POST['street'];
	$city = $_POST['city'];
	$pc = $_POST['pc'];
    $phone = $_POST['phone'];
	
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "restaurantDB";

    $con = new mysqli($servername, $username, $password, $dbname);
    if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }
	
	$querycheck = 'select email from customer where email = ?';
    $stm = $con->prepare($querycheck);
    $stm->bind_param("s", $email);
    $stm->execute();
    $result = $stm->get_result();
	
    if ($result->num_rows > 0) {
        echo "Error: Customer already exists.";
    } else {
        $query = "insert into customer (email, firstName, lastName, street, city, pc, phone) values (?, ?, ?, ?, ?, ?, ?)";
        $stm = $con->prepare($query);
        $stm->bind_param("sssssss", $email, $firstName, $lastName, $street, $city, $pc, $phone);
        $stm->execute();
		
        $amount = 5;
        $query = "insert into account (paymentdate, amountcredit, CustomerEmail) VALUES (CURDATE(), ?, ?)";
        $stm = $con->prepare($query);
        $stm->bind_param("ds", $amount, $email);
        $stm->execute();

        echo "New customer added successfully.";

        $stm->close();
        $con->close();
    }
}
?>
</body>
</html>