<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Resataurant</title>
	<link rel="stylesheet" type="text/css" href="restau.css">
</head>
<body>
<?php
include 'connectedRe.php';
?>
	<h1>Restaurant</h1>
	<h2>To view the order, please choose "View Order"</h2>
	<li><a href="view_orders.php">View Order</a>
	<h3>To add a new customer, please choose "Add Customer"</h3>
	<li><a href="addcustomer.php">Add Customer</a>
	<h4>To view the order table, please choose "Order Table"</h4>
	<li><a href="orderdatestable.php">Order Table</a>
	<h5>To view employee's schedule, please choose "View Schedule"</h5>
	<li><a href="viewschedule.php">View Schedule</a>
</body>
</html>